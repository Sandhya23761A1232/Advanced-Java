
package com.mycompany.servletcollaboration;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {

    // Sample login details stored in arrays
    private final String[] usernames = {"user1", "admin", "guest"};
    private final String[] passwords = {"pass1", "admin123", "guest123"};

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            // Include header servlet
            RequestDispatcher rd = request.getRequestDispatcher("/WelcomeServlet");
            rd.include(request, response);
            
            // Get login credentials
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            boolean authenticated = false;
            
            // Authenticate using arrays
            for (int i = 0; i < usernames.length; i++) {
                if (usernames[i].equals(username) && passwords[i].equals(password)) {
                    authenticated = true;
                    break;
                }
            }
            
            // Display result
            if (authenticated) {
                out.println("<h2>Login Successful!</h2>");
                out.println("<p>Welcome, " + username + ".</p>");
            } else {
                out.println("<h2>Login Failed!</h2>");
                out.println("<p>Invalid username or password.</p>");
            }
        }
    }
}
