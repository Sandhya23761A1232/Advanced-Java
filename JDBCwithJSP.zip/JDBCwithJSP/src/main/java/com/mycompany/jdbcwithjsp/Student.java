
package com.mycompany.jdbcwithjsp;

public class Student {
    private String srollno;
    private String sname;
    private String semail;
    private String sbranch;
    private String syear;
    private String ssec;

    // Getters & Setters
    public String getSrollno() { return srollno; }
    public void setSrollno(String srollno) { this.srollno = srollno; }

    public String getSname() { return sname; }
    public void setSname(String sname) { this.sname = sname; }

    public String getSemail() { return semail; }
    public void setSemail(String semail) { this.semail = semail; }

    public String getSbranch() { return sbranch; }
    public void setSbranch(String sbranch) { this.sbranch = sbranch; }

    public String getSyear() { return syear; }
    public void setSyear(String syear) { this.syear = syear; }

    public String getSsec() { return ssec; }
    public void setSsec(String ssec) { this.ssec = ssec; }
}

