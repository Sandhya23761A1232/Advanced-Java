package com.mycompany.jdbcwithjsp;

import java.sql.*;

public class StudentDAO {
    public static int myinsert(Student stu) {
        int status = 0;
        try {
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Connection (Change DB name, user, password as per your setup)
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/studentdb", "root", "");

            // Prepare SQL Insert Statement
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO students (srollno, sname, semail, sbranch, syear, ssec) VALUES (?,?,?,?,?,?)");

            ps.setString(1, stu.getSrollno());
            ps.setString(2, stu.getSname());
            ps.setString(3, stu.getSemail());
            ps.setString(4, stu.getSbranch());
            ps.setString(5, stu.getSyear());
            ps.setString(6, stu.getSsec());

            // Execute Update
            status = ps.executeUpdate();

            // Close Connection
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
}
