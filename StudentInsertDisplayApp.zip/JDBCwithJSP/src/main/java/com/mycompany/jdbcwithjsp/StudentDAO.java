package com.mycompany.jdbcwithjsp;

import java.sql.*;
import java.util.*;   // For List and ArrayList

public class StudentDAO {

    // Insert Method
    public static int myinsert(Student stu) {
        int status = 0;
        try {
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Connection
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/studentdb", "root", "");

            // Prepare SQL Insert Statement
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO students (srollno, sname, semail, sbranch, syear, ssec) VALUES (?,?,?,?,?,?)");

            ps.setString(1, stu.getSrollno());
            ps.setString(2, stu.getSname());
            ps.setString(3, stu.getSemail());
            ps.setString(4, stu.getSbranch());
            ps.setString(5, stu.getSyear());
            ps.setString(6, stu.getSsec());

            // Execute Update
            status = ps.executeUpdate();

            // Close Connection
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    // ✅ Display Records Method
    public static List<Student> getAllRecords() {
        List<Student> list = new ArrayList<>();

        try {
            // Load Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Connection
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/studentdb", "root", "");

            // Prepare SQL Select Statement
            PreparedStatement ps = con.prepareStatement("SELECT * FROM students");
            ResultSet rs = ps.executeQuery();

            // Process ResultSet
            while (rs.next()) {
                Student u = new Student();
                u.setSrollno(rs.getString("srollno"));
                u.setSname(rs.getString("sname"));
                u.setSemail(rs.getString("semail"));
                u.setSbranch(rs.getString("sbranch"));
                u.setSyear(rs.getString("syear"));
                u.setSsec(rs.getString("ssec"));

                list.add(u);   // Add each Student to list
            }

            // Debug Print
            System.out.println("Data: " + list);

            // Close Connection
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
