package com.mycompany.loginauthentication;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {

            String email = request.getParameter("email");
            String password = request.getParameter("password");

            if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
                out.println("<h3>Please enter both email and password!</h3>");
                return;
            }

            // Get DB init parameters from web.xml
            String dbURL = getServletConfig().getInitParameter("dbURL");
            String dbUser = getServletConfig().getInitParameter("dbuser");
            String dbPass = getServletConfig().getInitParameter("dbpass");

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");

                try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
                     PreparedStatement stmt = conn.prepareStatement(
                        "SELECT name FROM users WHERE email = ? AND password = ?")) {

                    stmt.setString(1, email);
                    stmt.setString(2, password);

                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            // ✅ fetch the name of user based on email
                            String uname = rs.getString("name");

                            // ✅ store name in session
                            HttpSession session = request.getSession();
                            session.setAttribute("key", uname);

                            // ✅ redirect to welcome servlet
                            response.sendRedirect("welcome");

                        } else {
                            out.println("<h3>Invalid email or password. Please try again.</h3>");
                            out.println("<a href='login.html'>Back to Login</a>");
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                out.println("<h3>Database error: " + e.getMessage() + "</h3>");
            }
        }
    }
}
