package com.mycompany.loginauthentication;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistrationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set content type before getting writer
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            // Get form data
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            // Simple input validation (optional)
            if (name == null || name.isEmpty() ||
                email == null || email.isEmpty() ||
                password == null || password.isEmpty()) {
                out.println("<h3>Please fill all the required fields!</h3>");
                return;
            }

            // Get DB init parameters from web.xml
            String dbURL = getServletConfig().getInitParameter("dbURL");
            String dbUser = getServletConfig().getInitParameter("dbuser");
            String dbPass = getServletConfig().getInitParameter("dbpass");

            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Use try-with-resources for DB connection and statement
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
                 PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO users (name, email, password) VALUES (?, ?, ?)")) {

                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, password);

                int result = stmt.executeUpdate();

                if (result > 0) {
                    out.println("<h3>Registration successful!</h3>");
                     out.println("<a href='login.html'>Go to Login</a>");
                   
                } else {
                    out.println("<h3>Registration failed. Please try again.</h3>");
                }

            } catch (SQLException sqle) {
                // Check if email uniqueness constraint failed
                if (sqle.getErrorCode() == 1062) { // MySQL duplicate entry error code
                    out.println("<h3>Error: This email is already registered!</h3>");
                } else {
                    sqle.printStackTrace();
                    out.println("<h3>Database error: " + sqle.getMessage() + "</h3>");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            // Since writer may be closed, just print stack trace for debugging
        }
    }
}
