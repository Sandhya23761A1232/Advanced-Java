
package com.mycompany.advancedjavaproject1;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FactorialServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           int num1=Integer.parseInt(request.getParameter("t1"));
           int f=1;
           for(int i=1;i<=num1;i++)
           {
               f=f*i;
           }
           out.println("The factorial of given number is:"+f);
            
        }
    }

    
}
