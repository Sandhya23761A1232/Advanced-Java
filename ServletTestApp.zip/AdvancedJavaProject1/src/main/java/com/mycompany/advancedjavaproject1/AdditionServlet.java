package com.mycompany.advancedjavaproject1;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdditionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            // Get all numbers as an array
            String[] numbers = request.getParameterValues("numbers");
            
            if (numbers == null || numbers.length == 0) {
                out.println("<h3>No numbers provided!</h3>");
                return;
            }
            
            int sum = 0;
            for (String numStr : numbers) {
                sum += Integer.parseInt(numStr);  // convert each to int and add
            }
            
            out.println("<h3>The sum of the given numbers is: " + sum + "</h3>");
        }
    }
}
