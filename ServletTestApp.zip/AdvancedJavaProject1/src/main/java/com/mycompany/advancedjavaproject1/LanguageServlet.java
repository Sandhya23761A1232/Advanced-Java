package com.mycompany.advancedjavaproject1;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LanguageServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String[] selectedLanguages = request.getParameterValues("languages");
            
            out.println("<h2>Selected Programming Languages:</h2>");
            
            if(selectedLanguages == null || selectedLanguages.length == 0) {
                out.println("<p>No language selected.</p>");
            } else {
                out.println("<ul>");
                for(String lang : selectedLanguages) {
                    out.println("<li>" + lang + "</li>");
                }
                out.println("</ul>");
            }
            
        }
    }
}
